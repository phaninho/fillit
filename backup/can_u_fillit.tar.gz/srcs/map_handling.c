/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_handling.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: stmartin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/01/18 18:48:34 by stmartin          #+#    #+#             */
/*   Updated: 2016/01/18 20:52:38 by stmartin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libit.h"

void	print_map(char **map)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	while (map && map[i])
	{
		while (map[i][j])
		{
			ft_putchar(map[i][j]);
			ft_putchar(' ');
			j++;
		}
		i++;
		j = 0;
		ft_putchar('\n');
	}
	ft_putchar('\n');
}

// Placer des obstacles
/* void	init_map(char **map) */

char		**map_alloc(char **map, int size)
{
	int		i;

	i = 0;
	if (!map)
	{
		if (!(map = (char **)malloc((sizeof(char *) * (size + 1)))))
			ft_error();
		map[size] = NULL;
		while (i < size)
		{
			if (!(map[i] = (char *)malloc((sizeof(char) * size + 1))))
				ft_error();
			map[i][size] = '\0';
			/* ft_memset(map[i], 'x', size); */
			i++;
		}
		ft_memset(map, 'x', sizeof(char *) * size);
		/* map[0][0] = 'x'; */
		/* map[0][1] = 'x'; */
		/* map[1][0] = 'x'; */
		/* map[1][1] = 'x'; */
	}

	return (map);
}

/*void	map_alloc(char ***map, int size)
{
	int		i;

	i = 0;
	// si map == NULL alloue de la memoire
	if (!*map)
	{
		if (!(*map = (char **)malloc(sizeof(char *) * (size + 1))))
			ft_error();
		*map[size] = NULL;
		while (i < size)
		{
			if (!(*map[i] = (char *)malloc(sizeof(char) * (size + 1))))
				ft_error();
			*map[i][size] = '\0';
			i++;
		}
		ft_memset(*map, '.', size * size);
	}
	printf("HERE\n");
	//else
	//{
	//}
	// si map != NULL genere une nouvelle map, copie de donnee
	// et suppression de l'ancienne map
}
*/

/* char 	**free_map(char **map) */

